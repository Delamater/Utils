﻿'Author:        Bob Delamater
'Date:          
'Description:   This class will compare a databases's views, 
'               functions, triggers, and stored procedures against 
'               another database using values stored within a dataset.
'               The output is in the form of a datatable.

Option Strict On
Option Explicit On

Public Class CompareDatabase

End Class

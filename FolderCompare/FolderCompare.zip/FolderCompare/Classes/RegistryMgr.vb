﻿'Author:        Bob Delamater
'Date:          05/23/2010
'Description:   This class is not implemented yet.
'Dependencies:  This class requires the constants.vb class

Option Explicit On
Option Strict On

Public Class RegistryMgr

End Class
